
const help = (prefix) => { 
	return `BOT G GUNA           
	
	   MENU BOT G GUNA

 *${prefix}owner*
 *${prefix}sticker
 *${prefix}sticker nobg*
 *${prefix}tsticker*
 *${prefix}nulis*
 *${prefix}ttp*
 *${prefix}glitch*
 *${prefix}lneon*
 *${setprefix}lwolf1*
 *${setprefix}lwolf2*
 *${prefix}ljoker*
 *${prefix}tts*
 *${prefix}tiktok*
 *${prefix}meme*
 *${prefix}memeindo*
 *${prefix}nsfwloli* 
 *${prefix}ocr*
 *${prefix}neko*
 *${prefix}ranime*
 *${prefix}loli*
 *${prefix}yt*
 *${prefix}play*
 *${prefix}add* [62xxx]
 *${prefix}kick* [tag]
 *${prefix}leave*
 *${prefix}out*
 *${prefix}linkgc*
 *${prefix}setpp*
 *${prefix}tagme*
 *${prefix}demote* [tag]
 *${prefix}promote* [tag]
 *${prefix}grup* [buka/tutup]
 *${prefix}welcome* [1/0]
 *${prefix}nsfw* [1/0]
 *${prefix}simih* [1/0]
 *${prefix}bc* 
 *${prefix}leave*
 *${prefix}clearall*
 *${prefix}setprefix*
 *${prefix}leave*
 *${prefix}clone* [tag]
 *${prefix}ban*
 *${prefix}unban*
 *${prefix}spsms*
 *${prefix}spcall*
 *${prefix}spgmail*
 *${prefix}ytsearch*
 *${prefix}listadmin*
 *${prefix}blocklist*
 *${prefix}simi*
 *${prefix}wait*
 *${prefix}nama*
 *${prefix}map*
 *${prefix}cerpen*
 *${prefix}qrcode*
 *${prefix}fitnah*
 *${prefix}tiktokstalk*
 *${prefix}url*
 *${prefix}url2img*
 *${prefix}alay*
 *${prefix}lirik*
 *${prefix}quotes*
 *${prefix}bucin*`
}

exports.help = help

 